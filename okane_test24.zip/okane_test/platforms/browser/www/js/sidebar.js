$(document).ready(function() {

  $("[data-toggle]").bind("tap", function() {
    var toggle_el = $(this).data("toggle");
    child = this.childNodes[1].classList;
    if (child.contains('material-design-hamburger__icon--to-arrow')) {
       child.remove('material-design-hamburger__icon--to-arrow');
       child.add('material-design-hamburger__icon--from-arrow');
       closeSidebar();
     } else {
       child.remove('material-design-hamburger__icon--from-arrow');
       child.add('material-design-hamburger__icon--to-arrow');
       openSidebar();
     }
  });
  $(".close-side").bind("tap", function(){
    closeSidebar();
    toggleMove();
  });
  function toggleMove(){
    var child = $('#hamburger');
    if (child.hasClass('material-design-hamburger__icon--to-arrow')) {
       child.removeClass('material-design-hamburger__icon--to-arrow');
       child.addClass('material-design-hamburger__icon--from-arrow');
     } else {
       child.removeClass('material-design-hamburger__icon--from-arrow');
       child.addClass('material-design-hamburger__icon--to-arrow');
     }
  }
        var SIDEBAR_WTH = 240;
        var currentSid = 0;
        var speed = 500;

        var swipeOptions = {
            triggerOnTouchEnd: true,
            swipeStatus: swipeStatus,
            allowPageScroll: "vertical",
            threshold: 75
        };

        $(function () {
            sidebar = $("#sidebar");
            sidebar.swipe(swipeOptions);
        });


        /**
         * Catch each phase of the swipe.
         * move : we drag the div
         * cancel : we animate back to where we were
         * end : we animate to the next image
         */
        function swipeStatus(event, phase, direction, distance) {
            //If we are moving before swipe, and we are going L or R in X mode, or U or D in Y mode then drag.
            if (phase == "move" && (direction == "left" || direction == "right")) {
                var duration = 0;

                if (direction == "left") {
                    scrollSidebar((distance * -1), duration);
                } else if (direction == "right") {
                    scrollSidebar((SIDEBAR_WTH*-1) + distance, duration);
                }

            } else if (phase == "cancel") {
              if (direction == "right") {
                if (distance >= (SIDEBAR_WTH/3)){
                  openSidebar();
                  toggleMove();
                } else{
                  closeSidebar();
                }
              } else if (direction == "left") {
                if (distance <= (SIDEBAR_WTH/3)){
                  openSidebar();
                } else{
                  closeSidebar();
                  toggleMove();
                }
              }
            } else if (phase == "end") {
                if (direction == "right") {
                  if (distance >= (SIDEBAR_WTH/3)){
                    openSidebar();
                    toggleMove();
                  } else{
                    closeSidebar();
                    toggleMove();
                  }
                } else if (direction == "left") {
                  if (distance <= (SIDEBAR_WTH/3)){
                    openSidebar();
                    toggleMove();
                  } else{
                    closeSidebar();
                    toggleMove();
                  }
                }
            }
        }

        function openSidebar() {
             sidebar.css("-webkit-transition-duration", "0.2s");
             sidebar.css("-webkit-transform", "translateX(0px)");

        }

        function closeSidebar() {
          sidebar.css("-webkit-transition-duration", "0.2s");
          sidebar.css("-webkit-transform", "translateX(-240px)");

        }

        /**
         * Manually update the position of the imgs on drag
         */
        function scrollSidebar(distance, duration) {
            sidebar.css("-webkit-transition-duration", "0s");

            //inverse the number we set in the css
            if (distance >= -240 && distance <= 0){
            var value = distance.toString();
            sidebar.css("-webkit-transform", "translate(" +value + "px, 0)");
          }
        }
    });
