/*add to product cart*/
jQuery(document).ready(function() {
  $('.cart').on('tap', function(){
    location.href = 'cart.html';
    return false;
  });
  $('.back-page').bind('tap', function(){
    if (document.referrer = 'check.html') {
      history.back(2);
    } else {
      history.back();
    }
    return false;
  });
  $('.background').width($(window).width());
  $('.background').height($(window).height());
    // Отобразим содержимое хранилища

        /*var output = 0;
        var postId = [];
        var postEd = [];
        for (var i = 0; i < $.cookie("qua"); i++) {
            var id = localStorage.key(i);
            if (id.substring(0,3) == "id_") {
            postId[i]=id.substring(3);
            postEd[i]=localStorage.getItem(localStorage.key(i));
            output = output + 1;
            }
        }
        localStorage.setItem("qua", output);*/
        var qua = 0;
        if (localStorage.getItem("qua")){
          qua = localStorage.getItem("qua");
        }
    $(".cart-qualyty").text(qua);
        //$(".cart").load($.get("http://bestway-asia.kz/wp-content/plugins/exxoos-cart-1/product-cart.php",{param1: "param1",param2: 2},onAjaxSuccess));
        //postviewCountGet(postId, postEd);
        //OrderBuyGet(postId, postEd);


    /*
    jQuery("#order-go").click(function(){
        var postId = [];
        var postEd = [];
        for (var i = 0; i < localStorage.length; i++) {
            var id = localStorage.key(i);
            if (id.substring(0,3) == "id_") {
            postId[i]=id.substring(3);
            postEd[i]=localStorage.getItem(localStorage.key(i));
            }
        }
        OrderMailTo(postId, postEd);
    });
    // проверка совместимости
    function web_storage() {
      try {
        return 'localStorage' in window && window['localStorage'] !== null;
    } catch (e) {
        return false;
      }
    }
    ref_cart(); */
// Добавить в корзину на странице категории
$('.category-product').on('tap', '.add-to-cart-butt', function(){
    var qua = 0;
    var reg = /[0-9]/,
        id = $(this).attr("data-id"),
        kolvo = 1;
    if (localStorage.getItem("qua")){
    qua = localStorage.getItem("qua");
    qua++;
    if (!localStorage.getItem("id_"+id)){
    localStorage.setItem("qua", qua);
    }
    localStorage.setItem("id_"+id, kolvo);
  }else{
    qua = 0;
    qua++;
    if (!localStorage.getItem("id_"+id)){
    localStorage.setItem("qua", qua);
    }
    localStorage.setItem("id_"+id, kolvo);
  }
    $(".cart-qualyty").text(Number(localStorage.getItem("qua")));

    $('.cart-qualyty').css({'width':'30px'});
    $('.cart-qualyty').css({'height':'30px'});
    $('.cart-qualyty').css({'line-height':'30px'});

    setTimeout(function(){
      $('.cart-qualyty').css({'width':'20px'});
      $('.cart-qualyty').css({'height':'20px'});
      $('.cart-qualyty').css({'line-height':'20px'});
    },200);
return false;
});
// Добавить в корзину на странице товара
$('.product-menu').on('click', '.add-to-cart', function(){

    var qua = 0;
    var reg = /[0-9]/,
        id = $(this).attr("data-menu_id"),
        kolvo = $(this).attr("data-menu_qa");
    if (localStorage.getItem("qua")){
    qua = localStorage.getItem("qua");
    qua++;
    if (!localStorage.getItem("id_"+id)){
    localStorage.setItem("qua", qua);
    }
    localStorage.setItem("id_"+id, kolvo);
  }else{
    qua = 0;
    qua++;
    if (!localStorage.getItem("id_"+id)){
    localStorage.setItem("qua", qua);
    }
    localStorage.setItem("id_"+id, kolvo);
  }
    $(".cart-qualyty").text(Number(localStorage.getItem("qua")));
    $('.qua-number').text('1');

    $('.cart-qualyty').css({'width':'30px'});
    $('.cart-qualyty').css({'height':'30px'});
    $('.cart-qualyty').css({'line-height':'30px'});

    setTimeout(function(){
      $('.cart-qualyty').css({'width':'20px'});
      $('.cart-qualyty').css({'height':'20px'});
      $('.cart-qualyty').css({'line-height':'20px'});
    },200);
return false;
});

$('.go-to-server').bind('tap', function(){
  if ($('.us-name').val() == '' || $('.us-phone').val() == '' || $('.us-city').val() == '') {
        $('.error-chk').text('Не заполнены обязательные поля формы.');
        if ($('.us-name').val() == '') {
            $('.us-name').css({'border-color':'#d8512d'});
            $('.name-lb').css({'color':'#d8512d'});
        };
        if ($('.us-phone').val() == '') {
            $('.us-phone').css({'border-color':'#d8512d'});
            $('.phone-lb').css({'color':'#d8512d'});
        };
        if ($('.us-city').val() == '') {
            $('.us-city').css({'border-color':'#d8512d'});
            $('.city-lb').css({'color':'#d8512d'});
        };
        setTimeout(function(){
        $('.checkout-action input').removeAttr('style');
        $('.checkout-action lable').removeAttr('style');
            },1000);
        }
        else {
  $.cookie("us-name", $('.us-name').val());
  $.cookie("us-phone", $('.us-phone').val());
  $.cookie("us-city", $('.us-city').val());
  $.cookie("us-street", $('.us-street').val());
  $.cookie("us-home-number", $('.us-home-number').val());
  $.cookie("us-kvartira", $('.us-kvartira').val());

  var order_l = '',
      order_k = '';
      order_s = '';
  for (var i = 0; i < localStorage.length; i++) {
  var id = localStorage.key(i),
      ed = localStorage.getItem(localStorage.key(i));
  if (id.substring(0,3) == "id_") {
    order_l = order_l + id.substring(3) + ',';
    order_k = order_k + ed + ',';
    if (localStorage.getItem('size_'+id.substring(3))){
    order_s = order_s + localStorage.getItem('size_'+id.substring(3)) + ',';
  } else { order_s = order_s + '0,'; }
  }
}
order_l = order_l.substring(0, order_l.length-1);
order_k = order_k.substring(0, order_k.length-1);
order_s = order_s.substring(0, order_s.length-1);
  $.get("http://okane.kz/okaneshop/api/add-reservation.php/?name="+$('.us-name').val()+"&phone="+$('.us-phone').val()+"&persone="+$('.us-persone').val()+"&city="+$('.us-city').val()+"&street="+$('.us-street').val()+"&home_number="+$('.us-home-number').val()+"&kvartira="+$('.us-kvartira').val()+"&comment="+$('.us-comment').val()+"&order_list="+order_l+"&order_kolvo="+order_k+"&order_size="+order_s);

  localStorage.clear();
  event.preventDefault();
  $('#overlay').fadeIn(400, // анимируем показ обложки
      function(){ // далее показываем мод. окно
          $('#modal_form')
              .css('display', 'block')
              .animate({opacity: 1, top: '50%'}, 200);
  });
}
});
});
